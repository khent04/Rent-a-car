__version__ = '0.7.8'
__VERSION__ = __version__
from .workbook import Workbook
